import os
from dotenv import load_dotenv
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

load_dotenv()

def test_openai_connection():
    try:
        response = client.chat.completions.create(model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Say hello."}
        ],
        temperature=0.7,
        max_tokens=50)
        print("Successfully connected to OpenAI!")
        print("Response:", response.choices[0].message.content.strip())
    except Exception as e:
        print("Error connecting to OpenAI:", e)

if __name__ == "__main__":
    test_openai_connection()
