from datetime import datetime, timedelta

def get_today():
    return datetime.utcnow().date()

def get_next_free_reading_type(user_data):
    """
    Returns: ('detailed_1card'|'detailed_3card'|'deep_dive_3card'), message, user_data (updated in-place)
    """
    today = get_today()
    last_date_str = user_data.get("last_reading_date")
    last_date = None
    if last_date_str:
        try:
            last_date = datetime.strptime(last_date_str, "%Y-%m-%d").date()
        except Exception:
            pass

    # Reset if user's data is inconsistent
    if 'signup_bonus_used' not in user_data:
        user_data['signup_bonus_used'] = False
    if 'streak_days' not in user_data:
        user_data['streak_days'] = 0
    if 'one_card_since_bonus' not in user_data:
        user_data['one_card_since_bonus'] = 0
    if 'three_card_bonuses' not in user_data:
        user_data['three_card_bonuses'] = 0
    if 'earned_deep_dive' not in user_data:
        user_data['earned_deep_dive'] = False

    streak = user_data.get('streak_days', 0)

    # 1. New user? Signup bonus!
    if not user_data['signup_bonus_used']:
        user_data['signup_bonus_used'] = True
        user_data['streak_days'] = 1
        user_data['one_card_since_bonus'] = 0
        user_data['three_card_bonuses'] = 0
        user_data['earned_deep_dive'] = False
        user_data['last_reading_date'] = today.strftime("%Y-%m-%d")
        return "detailed_3card", (
            "🌹 <b>Welcome!</b> You receive a <b>detailed three-card reading</b> as your first daily blessing.\n\n"
            "After this, you’ll receive a one-card reading each day—until you unlock your next three-card bonus!"), user_data

    # 2. If user missed a day, reset streak!
    if last_date:
        delta = (today - last_date).days
        if delta == 1:
            user_data['streak_days'] += 1
        elif delta > 1:
            # Missed a day
            user_data['streak_days'] = 1
            user_data['one_card_since_bonus'] = 0
            user_data['three_card_bonuses'] = 0
            user_data['earned_deep_dive'] = False
    else:
        user_data['streak_days'] = 1

    user_data['last_reading_date'] = today.strftime("%Y-%m-%d")

    # 3. Deep dive milestone
    if (not user_data['earned_deep_dive']
        and user_data['three_card_bonuses'] >= 5
        and user_data['one_card_since_bonus'] >= 24):
        user_data['earned_deep_dive'] = True
        return "deep_dive_3card", (
            "🌟 You have reached 29 days of daily devotion!\n\n"
            "Claim your <b>Deep Dive Three-Card Reading</b>—the most profound reading available to free members!"), user_data

    # 4. Bonus three-card (every 7th day, after 6 one-cards)
    if user_data['one_card_since_bonus'] >= 6:
        user_data['one_card_since_bonus'] = 0
        user_data['three_card_bonuses'] += 1
        return "detailed_3card", (
            f"✨ <b>Streak unlocked!</b>\nYou have received {user_data['three_card_bonuses']} bonus three-card readings.\n"
            "Today you get a <b>detailed three-card reading</b> as your streak reward!"), user_data
    else:
        user_data['one_card_since_bonus'] += 1
        return "detailed_1card", (
            f"🌱 Today you qualify for your daily <b>one-card reading</b>.\n"
            f"{6 - user_data['one_card_since_bonus'] + 1} more daily readings to unlock your next three-card bonus!"), user_data