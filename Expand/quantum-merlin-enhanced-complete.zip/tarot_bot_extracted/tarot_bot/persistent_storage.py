import sqlite3
import json

DB_FILE = "tarot_bot.db"

def poetic(msg: str) -> str:
    """Helper for pretty, poetic bot messaging format."""
    # Auto-add two line breaks where needed (after periods), preserve HTML.
    s = re.sub(r'([.!?]) ', r'\1\n\n', msg)
    # Small touches: center some stars at top, etc
    return f"<b>🌹✨</b>\n\n{s.strip()}"

def init_db():
    """Initializes the database and creates the user_data table if it doesn't exist."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_data (
            user_id INTEGER PRIMARY KEY,
            data TEXT
        )
    ''')
    conn.commit()
    conn.close()

def load_user_data(user_id: int) -> dict:
    """Loads user data from the database for a given user_id."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT data FROM user_data WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    if row:
        return json.loads(row[0])
    return {}

def save_user_data(user_id: int, data: dict):
    """Saves the user's data to the database."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    data_json = json.dumps(data)
    c.execute("INSERT OR REPLACE INTO user_data (user_id, data) VALUES (?, ?)", (user_id, data_json))
    conn.commit()
    conn.close()
