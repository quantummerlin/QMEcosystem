import logging
import os
import asyncio
import random
import re
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv

from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ConversationHandler,
    ContextTypes,
    filters,
)

# Load environment variables first
load_dotenv()
TOKEN = os.getenv("TELEGRAM_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

import asyncio
import openai

# Make sure your API key is set
openai.api_key = OPENAI_API_KEY

from datetime import datetime, timezone

# Set daily token limits by tier
DAILY_TOKEN_LIMITS = {
    "initiate": 1000,   # Free users
    "premium": 13000,   # For paid users (adjust as needed)
}
DEFAULT_TIER = "initiate"

def today_utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def poetic(msg, username=None):
    divider = '━' * 22
    header = '<b>🌹 The Rose of Sharon</b>' if not username else f"<b>🌹 The Rose of Sharon welcomes {username}</b>"
    footer = '<i>✨ Let your intuition blossom</i>'
    lines = [line.strip() for line in msg.strip().split('\n')]
    formatted_body = '\n\n'.join(lines)
    return (
        f"{divider}\n{header}\n{divider}\n\n"
        f"{formatted_body}\n\n"
        f"{divider}\n{footer}"
    )

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    username = update.effective_user.first_name
    # If you have load_user_data, uncomment below:
    # user_data = load_user_data(update.effective_user.id)
    # context.user_data.update(user_data)
    msg = welcome_message = (
    "🌹 Welcome, beloved seeker…\n\n"
    "You’ve stepped into the sacred sanctuary of The Rose of Sharon — a space for ritual, reflection, and intuitive guidance.\n\n"
    "🕊️ To begin, please enter your email address below.\n"
    "This unlocks your free daily tier and allows us to gently notify you when new mystical bots arrive in the BotWorld network.\n"
    "(Your inbox is sacred. No spam — ever.)\n\n"
    "———————————————\n"
    "<b>✨ Your Free Tier (The Initiate’s Path):</b>\n"
    "• Day 1: <b>3-card detailed reading</b> 🌟\n"
    "• Days 2–7: <b>1-card detailed reading</b> each day 🌱\n"
    "• Every 7th day: <b>3-card detailed reading</b> 🎉\n"
    "• After 28 days: <b>3-card deep dive reading</b> 🌑\n"
    "• Everything else is gently locked unless you choose to /upgrade.\n"
    "———————————————\n"
    "🌙 Want deeper insight and more energy each day?\n"
    "Type /upgrade at any time to explore premium tiers:\n\n"
    "🕯️ Seeker’s Daylight – 24 Hours – $1.99 (13,000 tokens)\n"
    "🔮 Weekly Wisdom – 7 Days – $9.99 (13,000 tokens/day)\n"
    "🌕 Mystic Circle – Monthly – $19.99/month (13,000 tokens/day)\n"
    "🌟 Year of Illumination – Annual – $100/year (13,000 tokens/day)\n"
    "💫 Spell Fuel – 13,000 extra tokens – $1.99 (used after daily quota)\n"
    "———————————————\n\n"
    "🌸 When you're ready, enter your email address to begin…"
    )
    await update.message.reply_text(poetic(msg, username), parse_mode="HTML")
    return EMAIL  # or return whatever state you use for your convo

from streak_logic import get_next_free_reading_type

from datetime import datetime, timezone, timedelta

def get_user_day_streak(user_data):
    """Returns how many unique days the user has done the daily reading."""
    # Let's use 'free_reading_dates' as a set of 'YYYY-MM-DD' strings.
    streak = 0
    if "free_reading_dates" in user_data:
        # Ensure sorted order!
        dates = sorted([datetime.strptime(d, "%Y-%m-%d").date() for d in user_data["free_reading_dates"]])
        today = datetime.now(timezone.utc).date()
        if not dates:
            return 0
        # Now walk backwards and count consecutive days up to today
        for idx, date in enumerate(reversed(dates)):
            if (today - date).days == idx:
                streak += 1
            else:
                break
    return streak

def get_today_free_reading_type(user_data):
    """
    Determines what type of free reading a user is eligible for today.
    Returns ("detailed_1card"|'detailed_3card'|'deep_dive_3card', message)
    """
    streak = get_user_day_streak(user_data)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # For legacy, ensure set exists
    user_data.setdefault("free_reading_dates", set())
    if isinstance(user_data["free_reading_dates"], list):
        # Migrate to set
        user_data["free_reading_dates"] = set(user_data["free_reading_dates"])

    # Did user do reading today?
    did_today = today in user_data["free_reading_dates"]

    # --- Now decide which reading is available:

    cycle_day = (streak % 7) or 7  # so day 7,14,21,28... are 3-card days

    # After 28 days, unlock deep dive (on day 28, 56, etc)
    if streak and streak % 28 == 0:
        return ("deep_dive_3card",
            "🎉 You've reached 28 days of daily devotion! A special <b>3-card deep dive</b> is unlocked for you today! 🌑"
        )
    elif streak == 0:
        return ("detailed_3card",
                "✨ Your path begins: a <b>3-card detailed reading</b> is unlocked for your first day.")
    elif cycle_day == 7:
        return ("detailed_3card",
                f"🌟 Day {streak}! Every seventh day, you receive a bonus <b>3-card detailed reading</b>!")
    else:
        return ("detailed_1card",
                f"🌱 Day {streak+1}: One <b>1-card detailed reading</b> is available today. Return every day for more to unlock deeper mysteries!")

# Usage: 
# rtype, msg = get_today_free_reading_type(user_data)

async def upgrade_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = (
        "<b>🌙 Unlock Deeper Mysteries</b>\n"
        "\n"
        "✨ <b>Seeker’s Daylight (24h):</b> $1.99\n"
        "🌕 <b>Mystic Circle (30 days):</b> $19.99\n"
        "🌟 <b>Year of Illumination (1 year):</b> $100\n"
        "\n"
        "<i>To purchase, reply here or contact @YourSupportHandle for gentle, manual activation while we prepare our payment portal.</i>"
    )
    await update.message.reply_text(poetic(msg), parse_mode="HTML")

    # 1. Paid Tier Definitions (place near your tier/token logic!)
PAID_TIERS = {
    "24h": {"name": "Seeker’s Daylight (24h)", "max_readings": 1, "period": "day"},
    "7d": {"name": "Weekly Wisdom (7d)",      "max_readings": 2, "period": "week"},
    "1m": {"name": "Mystic Circle (month)",   "max_readings": 5, "period": "month"},
    "1y": {"name": "Year of Illumination",    "max_readings": 60, "period": "year"},
}

# How many tokens each tier gets per day.
DAILY_TOKEN_LIMITS = {
    "initiate": 1000,
    "premium": 13000, # 24h
    "week": 13000,    # 7d
    "month": 13000,   # 1m
    "year": 13000     # 1y
}

async def codeword_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_data = load_user_data(user_id)

    # Get code from message
    parts = update.message.text.strip().split(" ")
    if len(parts) == 2 and parts[0] == "/codeword" and parts[1] == PREMIUM_CODE:
        user_data['tier'] = 'premium'
        save_user_data(user_id, user_data)
        await update.message.reply_text(poetic(
            "🌸 The secret rose has blossomed for you!\n\n"
            "You now have premium access forever. Thank you for tending the magic."
        ), parse_mode="HTML")
    else:
        await update.message.reply_text(poetic(
            "That secret does not open any gates here. Try again, or contact support."
        ), parse_mode="HTML")
        PREMIUM_CODE = "/SharonAlden"  # Or any code you like

def get_user_tier(user_data):
    if "paid_tier" in user_data:
        pt = user_data["paid_tier"]
        if pt == "24h":
            return "premium"
        elif pt == "7d":
            return "week"
        elif pt == "1m":
            return "month"
        elif pt == "1y":
            return "year"
    return user_data.get('tier', DEFAULT_TIER)

def get_token_info(user_data):
    # Ensures token_info is present and is for today
    tinfo = user_data.get('token_info', None)
    if not tinfo or 'date' not in tinfo or 'used' not in tinfo:
        tinfo = {"date": today_utc(), "used": 0}
        user_data['token_info'] = tinfo
    if tinfo['date'] != today_utc():
        tinfo['date'] = today_utc()
        tinfo['used'] = 0
    return tinfo

def check_quota_and_update(user_id, user_data, tokens_needed=0):
    """Checks if user can use tokens_needed more tokens. Updates count if so. Returns True/False."""
    tier = get_user_tier(user_data)
    max_tokens = DAILY_TOKEN_LIMITS.get(tier, 1000)
    tinfo = get_token_info(user_data)
    if tinfo['used'] + tokens_needed > max_tokens:
        return False
    tinfo['used'] += tokens_needed
    save_user_data(user_id, user_data)    # Save after update!
    return True

def get_last_journal_context(user_data):
    journal = user_data.get("journal", [])
    if not journal:
        return ""
    last_entry = journal[-1]
    return (
        f"Previous question: {last_entry.get('question','')}\n"
        f"User’s last reflection: {last_entry.get('reflection','')}\n"
    )

async def build_gpt_prompt(spread, focus, depth, card_names_text, user_data=None):
    MAX_PERSONA_LENGTH = 30000
    trimmed_reference = persona_context[:MAX_PERSONA_LENGTH]
    last_context = get_last_journal_context(user_data) if user_data else ""

    # Map reading depth to style instructions
    if depth == "direct":
        reading_style = "Keep each section concise (3-4 sentences total)."
    elif depth == "detailed":
        reading_style = "Give 7-10 total sentences, elaborating on key influences and guidance."
    elif depth == "deep_dive":
        reading_style = "Give a comprehensive deep dive (15-20 sentences total), exploring symbolism and offering extensive insight."
    else:
        reading_style = "Keep each section concise (3-4 sentences total)."

    base_prompt = (
        f"{trimmed_reference}\n\n"
        "Now, using the following tarot reading request:\n\n"
        f"User's most recent journal info: {last_context}\n\n"
        "You are <b>The Rose of Sharon</b>, a poetic, wise, and emotionally intelligent tarot mystic.\n\n"
        f"<b>Spread:</b> {spread}\n"
        f"<b>Focus:</b> {focus}\n"
        f"<b>Depth:</b> {depth}\n"
        f"<b>Drawn Cards:</b> {card_names_text}\n\n"
        "👉 Please write the reading in distinct HTML sections, one for each drawn card:\n"
        "• For each card, provide a divider line (━━━), include the card's emoji and name in bold, the card's position in italics if given, then a poetic, soulful interpretation.\n"
        "• If a card is reversed, state this after the card name.\n"
        "• After all cards, write a 'Summary & Blessing' section with an uplifting closing reflection.\n"
        "• Decorate with relevant emojis for each card.\n"
        "• Use <b>bold</b>, <i>italics</i>, and line breaks for clarity (Telegram HTML).\n"
        "• Avoid preamble—start directly with the first card's section.\n\n"
        f"{reading_style} Use rich, gentle metaphors and spiritual insight throughout."
    )

    return base_prompt

def load_persona_data(persona_folder="persona_folder", fallback_file="persona_the_rose_of_sharon.txt") -> str:
    """
    Attempts to load text from PDFs in the persona_folder.
    If no PDF text is found, it falls back to loading text from a fallback file.
    """
    combined_text = ""
    if os.path.isdir(persona_folder):
        for filename in os.listdir(persona_folder):
            if filename.lower().endswith(".pdf"):
                pdf_path = os.path.join(persona_folder, filename)
                try:
                    reader = PdfReader(pdf_path)
                    for page in reader.pages:
                        text = page.extract_text()
                        if text:
                            combined_text += text + "\n"
                except Exception as e:
                    print(f"Error reading {pdf_path}: {e}")
    if not combined_text:
        fallback_path = os.path.join(persona_folder, fallback_file)
        if os.path.isfile(fallback_path):
            try:
                with open(fallback_path, "r", encoding="utf-8") as f:
                    combined_text = f.read()
            except Exception as e:
                print(f"Error reading fallback file {fallback_path}: {e}")
    return combined_text.strip()

persona_context = load_persona_data("persona_folder")
print("📚 Persona loaded — length:", len(persona_context))
print("Loaded token:", TOKEN)
print("Loaded OpenAI API key:", OPENAI_API_KEY)

def load_reference_document(filepath="persona_folder/deep_tarot_reference.txt") -> str:
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception as e:
        print(f"Error loading reference document: {e}")
        return ""

def split_telegram_message(text, max_length=4096):
    """
    Splits a long message into chunks for Telegram (keeping line breaks).
    """
    lines = text.split('\n')
    chunks = []
    current = ""
    for line in lines:
        if len(current) + len(line) + 1 > max_length:
            chunks.append(current)
            current = ""
        current += line + "\n"
    chunks.append(current)
    return chunks

deep_tarot_reference = load_reference_document()
print("Deep Tarot Reference loaded — length:", len(deep_tarot_reference))

# Setup OpenAI client using new API format
from openai import OpenAI
client = OpenAI(api_key=OPENAI_API_KEY)

# Telegram imports
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ConversationHandler,
    ContextTypes,
    filters,
)

# Persistent storage handlers (ensure these are implemented)
from persistent_storage import init_db, load_user_data, save_user_data
init_db()

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def poetic(msg: str) -> str:
    """Helper for pretty, poetic bot messaging format."""
    # Auto-add two line breaks where needed (after periods), preserve HTML.
    s = re.sub(r'([.!?]) ', r'\1\n\n', msg)
    # Small touches: center some stars at top, etc
    return f"<b>🌹✨</b>\n\n{s.strip()}"

# Define conversation states.
EMAIL, SPREAD, FOCUS, DEPTH, SAY, REFLECTION = range(6)

#########################
#    Helper Functions   #
#########################
def escape_md(text: str) -> str:
    # Not needed with HTML formatting.
    return text

async def free_user_reading_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_data = load_user_data(user_id)
    
    # Check if premium (leave logic for premium as is!)
    if get_user_tier(user_data) == "premium":
        await start_reading(update, context)
        return

    reading_type, message, user_data = get_next_free_reading_type(user_data)
    save_user_data(user_id, user_data)

    if reading_type == "detailed_1card":
        reply = (
            f"{message}\n\n"
            "To receive your one-card reading, type <b>/1</b>."
        )
    elif reading_type == "detailed_3card":
        reply = (
            f"{message}\n\n"
            "To receive your special three-card reading, type <b>/3bonus</b>."
        )
    elif reading_type == "deep_dive_3card":
        reply = (
            f"{message}\n\n"
            "To receive your deep-dive three-card reading, type <b>/deepdive</b>."
        )
    else:
        reply = "An error occurred while determining your reading. Please try again."

    await update.message.reply_text(reply, parse_mode="HTML")
    context.user_data['free_reading_type'] = reading_type  # Store for later

# --- Core Spread Data ---

# Nine core spreads with keys "1" to "9"
spread_mapping = {
    "1": ("Three Card", "🧭 Three Card: The timeless triad. Reveal what shaped you, what holds you now, and what fate silently waits ahead."),
    "2": ("Celtic Cross", "🔍 Celtic Cross: Dive deep into your situation—both seen and hidden. Perfect for complex crossroads."),
    "3": ("Relationship", "💞 Relationship: Unlock the hidden energies flowing between you and another. See their truth; see yours."),
    "4": ("Decision Maker", "⚖️ Decision Maker: Compare two potential paths. Feel into both so you can choose with certainty."),
    "5": ("Shadow Work", "🌑 Shadow Work: Venture into the hidden aspects of yourself. Reveal wounds and transform them into strength."),
    "6": ("Love Insight", "💖 Love Insight: Explore the depths of your romantic energy. What is real, what is desired, and what can be nurtured."),
    "7": ("Elemental Balance", "🌿 Elemental Balance: Assess the harmony of Earth, Air, Fire, Water, and Spirit within you."),
    "8": ("Manifestation", "🪄 Manifestation: Uncover the block between you and your desires. Align your energy and claim your power."),
    "9": ("Spiritual Path", "🌟 Spiritual Path: Embark on a journey of inner discovery. Listen to your soul and step forward with divine guidance.")
}

# Number of cards to draw per spread.
spread_card_counts = {
    "Three Card": 3,
    "Celtic Cross": 10,
    "Relationship": 2,
    "Decision Maker": 2,
    "Shadow Work": 3,
    "Love Insight": 3,
    "Elemental Balance": 5,
    "Manifestation": 2,
    "Spiritual Path": 1
}

# If available, define position labels for spreads.
spread_positions = {
    "Three Card": ["Past", "Present", "Future"],
    "Celtic Cross": ["Present", "Challenge", "Past", "Future", "Advice", "Outcome", "Subconscious", "External", "Hopes/Fears", "Final Outcome"],
    "Relationship": ["Your Energy", "Their Energy"],
    "Decision Maker": ["Option 1", "Option 2"],
    "Shadow Work": ["Hidden Wounds", "Transformation", "Liberation"],
    "Love Insight": ["Your Energy", "Partner's Energy", "Bond"],
    "Elemental Balance": ["Earth", "Air", "Fire", "Water", "Spirit"],
    "Manifestation": ["Desire", "Block", "Alignment"],
    "Spiritual Path": ["Current Path"]
}

# Example card mapping for Major Arcana images.
card_mapping = {
    "The Fool": r"C:\Users\WIPED\tarot_bot\images\The_Fool.jpg",
    "The Magician": r"C:\Users\WIPED\tarot_bot\images\The_Magician.jpg",
    "The High Priestess": r"C:\Users\WIPED\tarot_bot\images\The_High_Priestess.jpg",
    "The Empress": r"C:\Users\WIPED\tarot_bot\images\The_Empress.jpg",
    "The Emperor": r"C:\Users\WIPED\tarot_bot\images\The_Emperor.jpg",
    "The Hierophant": r"C:\Users\WIPED\tarot_bot\images\The_Hierophant.jpg",
    "The Lovers": r"C:\Users\WIPED\tarot_bot\images\The_Lovers.jpg",
    "The Chariot": r"C:\Users\WIPED\tarot_bot\images\The_Chariot.jpg",
    "Strength": r"C:\Users\WIPED\tarot_bot\images\Strength.jpg",
    "The Hermit": r"C:\Users\WIPED\tarot_bot\images\The_Hermit.jpg",
    "Wheel of Fortune": r"C:\Users\WIPED\tarot_bot\images\Wheel_of_Fortune.jpg",
    "Justice": r"C:\Users\WIPED\tarot_bot\images\Justice.jpg",
    "The Hanged Man": r"C:\Users\WIPED\tarot_bot\images\The_Hanged_Man.jpg",
    "Death": r"C:\Users\WIPED\tarot_bot\images\Death.jpg",
    "Temperance": r"C:\Users\WIPED\tarot_bot\images\Temperance.jpg",
    "The Devil": r"C:\Users\WIPED\tarot_bot\images\The_Devil.jpg",
    "The Tower": r"C:\Users\WIPED\tarot_bot\images\The_Tower.jpg",
    "The Star": r"C:\Users\WIPED\tarot_bot\images\The_Star.jpg",
    "The Moon": r"C:\Users\WIPED\tarot_bot\images\The_Moon.jpg",
    "The Sun": r"C:\Users\WIPED\tarot_bot\images\The_Sun.jpg",
    "Judgement": r"C:\Users\WIPED\tarot_bot\images\Judgement.jpg",
    "The World": r"C:\Users\WIPED\tarot_bot\images\The_World.jpg",
}

# Mapping of some Major Arcana cards to representative emojis.
card_emojis = {
    "The Fool": "🤡",
    "The Magician": "🪄",
    "The High Priestess": "🔮",
    "The Empress": "👑",
    "The Emperor": "⚔️",
    "The Hierophant": "📿",
    "The Lovers": "💞",
    "The Chariot": "🏎️",
    "Strength": "💪",
    "The Hermit": "🕯️",
    "Wheel of Fortune": "🎡",
    "Justice": "⚖️",
    "The Hanged Man": "🤸",
    "Death": "💀",
    "Temperance": "🍃",
    "The Devil": "😈",
    "The Tower": "🏰",
    "The Star": "⭐",
    "The Moon": "🌙",
    "The Sun": "☀️",
    "Judgement": "🔔",
    "The World": "🌍"
}

REVERSED_PROBABILITY = 0.11  # Set the reversed probability

def draw_cards_by_spread(spread: str) -> list:
    """
    Draws a list of random cards based on the spread type.
    For each card drawn, randomly decide if it's reversed.
    Returns a list of tuples: (card_name, is_reversed)
    """
    num_cards = spread_card_counts.get(spread, 1)
    available_cards = list(card_mapping.keys())
    num_cards = min(num_cards, len(available_cards))
    drawn = random.sample(available_cards, num_cards)
    result = []
    for card in drawn:
        is_reversed = random.random() < REVERSED_PROBABILITY
        result.append((card, is_reversed))
    return result

##############################
#     Command Handlers       #
##############################

# --- Email Capture Flow ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handles /start: asks for the user's email address."""
    user_id = update.effective_user.id
    user_data = load_user_data(user_id)
    context.user_data.update(user_data)
    if not context.user_data.get("email"):
        welcome_message = (
            "🌹 Welcome, beloved seeker…\n\n"
            "You’ve stepped into the sacred sanctuary of The Rose of Sharon — a space for ritual, reflection, and intuitive guidance.\n\n"
            "This is a journal-based spiritual tool. Nothing you say is saved unless you choose to write it down after a reading.\n"
            "Your voice becomes your memory. Your words become your map.\n\n"
            "🕊️ To begin, please enter your email address below.\n"
            "This unlocks your free daily tier and allows us to gently notify you when new mystical bots arrive in the BotWorld network.\n"
            "(Your inbox is sacred. No spam — ever.)\n\n"
            "———————————————\n"
            "✨ Your Current Tier: Initiate (Free)\n"
            "• 1,000 tokens per day\n"
            "• 3-card readings\n"
            "• Journal reflections\n"
            "• Moon messages\n\n"
            "🌙 Want deeper insight and more energy each day?\n"
            "Type /upgrade at any time to explore premium tiers:\n\n"
            "🕯️ Seeker’s Daylight – 24 Hours – $1.99 (13,000 tokens)\n"
            "🔮 Weekly Wisdom – 7 Days – $9.99 (13,000 tokens/day)\n"
            "🌕 Mystic Circle – Monthly – $19.99/month (13,000 tokens/day)\n"
            "🌟 Year of Illumination – Annual – $100/year (13,000 tokens/day)\n"
            "💫 Spell Fuel – 13,000 extra tokens – $1.99 (used after daily quota)\n"
            "———————————————\n\n"
            "🌸 When you're ready… whisper /reading to begin."
        )
        await update.message.reply_text(welcome_message, parse_mode="HTML")
        return EMAIL
    await update.message.reply_text(
        "🌹 Welcome back, beloved seeker.\nClick /reading to begin your free daily tarot reading.",
        parse_mode="HTML"
    )
    return ConversationHandler.END

async def capture_email(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    email = update.message.text.strip()
    if re.match(r"[^@]+@[^@]+\.[^@]+", email):
        context.user_data["email"] = email
        save_user_data(update.effective_user.id, context.user_data)
        await update.message.reply_text(
            "🌹 Thank you, dear seeker. Your sacred email has been recorded. You’ll be notified when new mystical tools arrive.\n\n"
            "Click /reading to begin your free daily tarot reading.",
            parse_mode="HTML"
        )
        return ConversationHandler.END
    else:
        await update.message.reply_text(
            "That doesn’t appear to be a valid email. Please try again.\n\n"
            "🌑 This part of the garden is reserved for those who have stepped deeper into the mystery…\n"
            "Type /upgrade to see how you can open this gate.",
            parse_mode="HTML"
        )
        return EMAIL

# --- Reading Flow: Spread Selection ---
async def start_reading(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    spread_menu = (
        "✨ <b>Choose your spread</b> ✨\n\n"
        "🔮 /1 – <b>Three-Card</b>\n<i>Past, Present, Future</i>\n"
        "🗝️ /2 – <b>Celtic Cross</b>\n<i>Deep overview</i>\n"
        "💌 /3 – <b>Relationship</b>\n<i>Energy between two</i>\n"
        "⚖️ /4 – <b>Decision Maker</b>\n<i>Compare paths</i>\n"
        "🌑 /5 – <b>Shadow Work</b>\n<i>Reveal inner blocks</i>\n"
        "💖 /6 – <b>Love Insight</b>\n<i>Romantic connection</i>\n"
        "🌿 /7 – <b>Elemental Balance</b>\n<i>Assess life energies</i>\n"
        "🪄 /8 – <b>Manifestation</b>\n<i>Align your desires</i>\n"
        "🌟 /9 – <b>Spiritual Path</b>\n<i>Divine guidance</i>\n\n"
        "<i>The choice is yours, my dearest beloved.</i>"
    )
    await update.message.reply_text(spread_menu, parse_mode="HTML")
    return SPREAD

async def select_spread_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    command = update.message.text.strip()
    if command.startswith('/'):
        command = command[1:]
    if command in spread_mapping:
        spread_name, info_text = spread_mapping[command]
        context.user_data["spread"] = spread_name
        await update.message.reply_text(info_text, parse_mode="HTML")
        await update.message.reply_text(
            "🌹 When you're ready, I’ll begin to draw back the veil...\n"
            "/proceed — Let your reading bloom with wisdom.\n"
            "/reading — Return to choose another spread.",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            "Please choose a valid option from the menu, or type /reading to see the spreads again.",
            parse_mode="HTML"
        )
    return SPREAD

async def one_card_reading(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Only let them if today is a 1-card day
    if context.user_data.get('free_reading_type') != "detailed_1card":
        await update.message.reply_text("Today you do not qualify for a 1-card reading. Type /reading for your available reading!")
        return
    # Actually perform the one-card reading
    context.user_data['spread'] = "Spiritual Path"  # Or use/call your 1-card spread
    context.user_data['depth'] = "detailed"
    await deliver_reading(update, context)

async def three_card_bonus_reading(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data.get('free_reading_type') != "detailed_3card":
        await update.message.reply_text("Today you do not qualify for a three-card bonus reading. Type /reading for your available reading!")
        return
    context.user_data['spread'] = "Three Card"
    context.user_data['depth'] = "detailed"
    await deliver_reading(update, context)

async def deep_dive_reading(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data.get('free_reading_type') != "deep_dive_3card":
        await update.message.reply_text("You do not qualify for a deep-dive reading today. Type /reading for your available reading!")
        return
    context.user_data['spread'] = "Three Card"
    context.user_data['depth'] = "deep_dive"
    await deliver_reading(update, context)

# --- Focus State ---
async def proceed_reading(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    print("proceed_reading() triggered")
    await update.message.reply_text(
        "✨ Let’s focus your energy…\n"
        "What area of your life would you like this reading to illuminate? Choose one:\n\n"
        "❤️ /love\n💼 /career\n💰 /money\n👨‍👩‍👧 /family\n💖 /health\n🌙 /spirituality\n🌱 /growth",
        parse_mode="HTML"
    )
    return FOCUS

async def set_predefined_focus(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    command = update.message.text.strip('/').lower()
    context.user_data["focus"] = command.capitalize()
    await update.message.reply_text(
        f"🌹 Focus set to: <i>{context.user_data['focus']}</i>.\n"
        "Now, please choose your reading depth:\n"
        "🌟 /direct — Brief reading (3-4 sentences)\n"
        "💫 /detailed — Detailed reading (7-10 sentences)\n"
        "🌌 /deep_dive — Deep dive reading (15-20 sentences)\n"
        "Or type <b>no</b> to use a brief reading by default.",
        parse_mode="HTML"
    )
    return DEPTH

async def set_depth_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    depth_choice = update.message.text.strip('/').lower()
    if depth_choice in ["no", ""]:
        depth_choice = "direct"
    user_data = context.user_data
    user_id = update.effective_user.id
    tier = get_user_tier(user_data)

    if depth_choice == "deep_dive" and tier == "initiate":
        await update.message.reply_text(
            poetic(
                "🌚 Dear seeker, the 'Deep Dive' reading is reserved for those who have stepped further on the path. "
                "To unlock this, consider an /upgrade.\n\n"
                "For now, please select a Direct or Detailed reading. 🌱"
            ),
            parse_mode="HTML"
        )
        return DEPTH

    user_data["depth"] = depth_choice
    await update.message.reply_text(
        poetic(
            f"You’ve chosen a <b>{depth_choice.capitalize()}</b> reading.\n\nWhen you're ready, type <b>/here</b> to receive your full reading."
        ),
        parse_mode="HTML"
    )
    return SAY

async def generate_gpt_reading(prompt, user_id=None, user_data=None):
    try:
        response = await asyncio.to_thread(
            lambda: client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}]
            )
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"Error generating GPT reading: {e}")
        return None
    
async def three_card_bonus_reading(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_data = load_user_data(user_id)
    if get_user_tier(user_data) == "initiate":
        # Only qualify if today's reading_type is "detailed_3card"
        reading_type, _ = get_today_free_reading_type(user_data)
        if reading_type != "detailed_3card":
            await update.message.reply_text("🔒 This reading is locked for you today. Type /reading to see what is available!")
            return
    context.user_data['spread'] = "Three Card"
    context.user_data['depth'] = "detailed"
    await deliver_reading(update, context)

async def deliver_reading(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_id = update.effective_user.id
    user_data = context.user_data
    spread = user_data.get('spread', 'Not specified')
    focus = user_data.get('focus', 'None')
    depth = user_data.get('depth', 'direct')

    tier = get_user_tier(user_data)
    max_tokens = DAILY_TOKEN_LIMITS.get(tier, 1000)
    tinfo = get_token_info(user_data)
    tokens_used = tinfo['used']

    # Paid logic
    if tier != "initiate":
        reset_paid_tier_readings_if_needed(user_data)
        allowed, remaining = can_paid_user_read(user_data)
        save_user_data(user_id, user_data)
        if not allowed:
            info = PAID_TIERS[user_data["paid_tier"]]
            await update.message.reply_text(
                f"⚠️ You've used all your readings for your current paid plan!\n"
                f"({info['max_readings']} per {info['period']}). Please wait for reset or /upgrade.",
                parse_mode="HTML"
            )
            return ConversationHandler.END

    # Free tier quota check
    if tokens_used >= max_tokens and tier == "initiate":
        await update.message.reply_text(
            poetic(
                "🌑 Beloved, your daily energy has been fully poured into the sacred flame (quota reached).\n"
                "Return at dawn for more insight, or consider an /upgrade for deeper wisdom.\n\n"
                "The Rose always waits for you."
            ),
            parse_mode="HTML"
        )
        return ConversationHandler.END

    # Show card draws
    await update.message.reply_text(poetic("🕯️ The candle flickers as I shuffle the cards..."), parse_mode="HTML")
    await asyncio.sleep(2)
    await update.message.reply_text(poetic("🔮 The veil parts. Your reading begins now..."), parse_mode="HTML")
    await asyncio.sleep(1)

    drawn_cards = draw_cards_by_spread(spread)
    positions = spread_positions.get(spread, [f"Card {i+1}" for i in range(len(drawn_cards))])

    for i, (card, reversed_status) in enumerate(drawn_cards):
        position_label = positions[i] if i < len(positions) else f"Card {i+1}"
        announcement = f"Drawing the <b>{position_label}</b>..."
        await update.message.reply_text(poetic(announcement), parse_mode="HTML")
        await asyncio.sleep(2)
        emoji = card_emojis.get(card, "")
        card_display = f"{emoji} {card} (Reversed)" if reversed_status else f"{emoji} {card}"
        caption = f"Your {position_label} is: <b>{card_display}</b>"
        image_path = card_mapping.get(card)
        if image_path and os.path.isfile(image_path):
            with open(image_path, "rb") as photo_file:
                await update.message.reply_photo(photo=photo_file, caption=caption, parse_mode="HTML")
        else:
            await update.message.reply_text(poetic(caption), parse_mode="HTML")
        await asyncio.sleep(2)

    card_names_text = ", ".join([
        f"{card_emojis.get(card, '')} {card} (Reversed)" if rev else f"{card_emojis.get(card, '')} {card}"
        for card, rev in drawn_cards
    ])

    # Build prompt for GPT
    base_prompt = await build_gpt_prompt(spread, focus, depth, card_names_text, user_data)
    reading = await generate_gpt_reading(base_prompt, user_id, user_data)

    if reading is None:
        await update.message.reply_text(
            poetic(
                "🌑 The day’s mystical energies are spent (quota reached).\n\n"
                "Please return at dawn, or open the garden with an /upgrade. 🌕"
            ),
            parse_mode="HTML"
        )
        return ConversationHandler.END

    for chunk in split_telegram_message(poetic(reading)):
        await update.message.reply_text(chunk, parse_mode="HTML")

    user_data["last_reading"] = reading
    user_data["drawn_cards"] = [c[0] for c in drawn_cards]
    save_user_data(user_id, user_data)

    # --- Mark today's free reading as used! (This is the FIX) ---
    if get_user_tier(user_data) == "initiate":
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        # Make sure our date-tracking set exists (migrating old data if needed)
        user_data.setdefault("free_reading_dates", set())
        if isinstance(user_data["free_reading_dates"], list):
            user_data["free_reading_dates"] = set(user_data["free_reading_dates"])
        user_data["free_reading_dates"].add(today)
        # If saving as JSON, sets should be lists:
        save_user_data(user_id, user_data)

    await update.message.reply_text(
        poetic(
            "Would you like to reflect in your tarot journal?\n"
            "<i>(Type your thoughts now and I’ll remember them in the garden journal. Or type /reading to ask again.)</i>"
        ),
        parse_mode="HTML"
    )

    return REFLECTION

from datetime import datetime

import openai
import io

openai.api_key = "sk-..."  # put your API key here, or load from env

async def tts_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_data = load_user_data(user_id)
    last_reading = user_data.get("last_reading", "")
    tier = get_user_tier(user_data)

    if not last_reading or tier == "initiate":
        await update.message.reply_text("TTS is only available for paid users who have a reading to hear.")
        return

    # OpenAI TTS
    response = openai.audio.speech.create(
        model="tts-1",                       # Or "tts-1-hd" for even better voices!
        voice="nova",                        # Try "alloy", "echo", "fable", "onyx", "nova", or "shimmer"
        input=last_reading
    )
    buf = io.BytesIO(response.content)       # response.content is bytes

    await update.message.reply_voice(voice=buf, caption="Here is your reading as audio! 🎤")

def reset_paid_tier_readings_if_needed(user_data):
    now = datetime.utcnow()
    tier = user_data.get('paid_tier')
    expiry = user_data.get('tier_expiry')
    last_used_str = user_data.get('tier_last_used')
    tier_info = PAID_TIERS.get(tier, None)

    # Expiry check
    if expiry:
        expiry_dt = datetime.strptime(expiry, "%Y-%m-%dT%H:%M:%S")
        if now > expiry_dt:
            # Downgrade user, clean out paid fields
            for k in ("paid_tier", "tier_expiry", "tier_readings_used_period", "tier_last_used"):
                user_data.pop(k, None)
            return

    if not tier_info:
        return
    
    p = tier_info["period"]
    reset = False

    if last_used_str:
        last_used = datetime.strptime(last_used_str, "%Y-%m-%d").date()
        if p == "day" and last_used != now.date():
            reset = True
        elif p == "week" and last_used.isocalendar()[1] != now.date().isocalendar()[1]:
            reset = True
        elif p == "month" and (last_used.year != now.year or last_used.month != now.month):
            reset = True
        elif p == "year" and last_used.year != now.year:
            reset = True

    if reset:
        user_data["tier_readings_used_period"] = 0

    user_data["tier_last_used"] = now.strftime("%Y-%m-%d")

def can_paid_user_read(user_data):
    tier = user_data.get('paid_tier')
    tier_info = PAID_TIERS.get(tier)
    if not tier_info:
        return False, 0
    max_readings = tier_info["max_readings"]
    used = user_data.get("tier_readings_used_period", 0)
    if used < max_readings:
        user_data["tier_readings_used_period"] = used + 1
        return True, max_readings - (used + 1)
    else:
        return False, 0

async def user_reflection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    journal_text = update.message.text.strip()
    user_id = update.effective_user.id
    user_data = context.user_data

    log = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "focus": user_data.get("focus", ""),
        "spread": user_data.get("spread", ""),
        "depth": user_data.get("depth", ""),
        "question": user_data.get("question", ""),
        "cards": user_data.get("drawn_cards", []),
        "reading": user_data.get("last_reading", ""),
        "reflection": journal_text,
    }
    user_data.setdefault("journal", []).append(log)
    save_user_data(user_id, user_data)

    await update.message.reply_text(poetic(
        "Your reflection has been gently recorded in your journal. 🌸\n\n"
        "<i>You may return to your memories at any time via /journal.</i>\n\n"
        "To consult the cards again, type /reading"
    ), parse_mode="HTML")
    return ConversationHandler.END

async def off_script_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_question = update.message.text
    prompt = (
        f"The user asked an off-script question: '{user_question}'\n"
        "Please provide a helpful, detailed answer as a tarot reading assistant would."
    )
    try:
        answer = await generate_gpt_reading(prompt)
    except Exception as e:
        await update.message.reply_text("I'm sorry, I couldn't generate an answer right now.", parse_mode="HTML")
        return ConversationHandler.END
    await update.message.reply_text(answer, parse_mode="HTML")
    return REFLECTION

async def locked_for_free_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "That reading is reserved for premium members or as a special bonus reward.\n"
        "Tap /reading to see what’s available for you today! 🌹"
    )

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("No worries. Whenever you're ready, just type /reading to start a new session.", parse_mode="HTML")
    return ConversationHandler.END

def main() -> None:
    application = ApplicationBuilder().token(TOKEN).build()
    
    conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler('start', start),
            CommandHandler('reading', start_reading),
        ],
        states={
            EMAIL: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, capture_email)
            ],
            SPREAD: [
                # /1 to /9 select spread (they show info text & ask for /proceed)
                CommandHandler([str(i) for i in range(1, 10)], select_spread_handler),
                CommandHandler('proceed', proceed_reading),
                CommandHandler('reading', start_reading),
            ],
            FOCUS: [
                CommandHandler('love', set_predefined_focus),
                CommandHandler('career', set_predefined_focus),
                CommandHandler('money', set_predefined_focus),
                CommandHandler('family', set_predefined_focus),
                CommandHandler('health', set_predefined_focus),
                CommandHandler('spirituality', set_predefined_focus),
                CommandHandler('growth', set_predefined_focus),
                CommandHandler('reading', start_reading),
            ],
            DEPTH: [
                CommandHandler('direct', set_depth_command),
                CommandHandler('detailed', set_depth_command),
                CommandHandler('deep_dive', set_depth_command),
                CommandHandler('no', set_depth_command),
                CommandHandler('reading', start_reading),
            ],
            SAY: [
                CommandHandler('here', deliver_reading),
                CommandHandler('reading', start_reading),
            ],
            REFLECTION: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, user_reflection),
                CommandHandler('no', user_reflection),
                CommandHandler('reading', start_reading),
            ],
        },
        fallbacks=[CommandHandler('cancel', cancel)],
        allow_reentry=True
    )

    # Add ConversationHandler FIRST so it gets first shot
    application.add_handler(conv_handler)

    # Global “jump out” commands for anything outside the conversation, or to provide extras:
    application.add_handler(CommandHandler('upgrade', upgrade_handler))
    application.add_handler(CommandHandler('codeword', codeword_handler))
    application.add_handler(CommandHandler('tts', tts_handler))
    
    # Special reading options after free_user_reading_menu (stub functions as example)
    application.add_handler(CommandHandler('1', one_card_reading))
    application.add_handler(CommandHandler('3bonus', three_card_bonus_reading))
    application.add_handler(CommandHandler('deepdive', deep_dive_reading))

    # /reading always works everywhere (resets to spread)
    application.add_handler(CommandHandler('reading', start_reading))
    # Fallback for unexpected text: off script Q&A
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, off_script_handler))

    application.run_polling()

if __name__ == '__main__':
    main()